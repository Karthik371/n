/** @format */

import React, { useEffect, useState } from "react";
import {
  AiOutlineFacebook,
  AiOutlineInstagram,
  AiOutlineTwitter,
} from "react-icons/ai";
import { FiAlertTriangle } from "react-icons/fi";
import { useParams, Link } from "react-router-dom";
import { Controller, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import csc from "country-state-city";

import axios from "axios";

import NavHeader from "./NavComponents/NavHeader";

// import { ICountry, IState, ICity } from "country-state-city";

const Services = () => {
  const ids = useParams();
  const [value, setValue] = useState();
  const [state, setState] = useState();
  const [countryCode, setCountryCode] = useState([]);
  const [selectedState, setSelectedState] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [cities, setCities] = useState();
  const [datas, setData] = useState({});

  const {
    control,
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const country = csc.getAllCountries();

  const onSubmit = (data) => {
    data.phoneNumber = value;
    data.state = selectedState;
    data.city = selectedCity;
    data.countryCode = countryCode;

    axios.post("/services", data, {
      headers: {
        "Content-type": "application/json",
      },
    });
  };
  const handleCountries = (e) => {
    let cont = e.target.value;
    setCountryCode(cont);
    const state = csc.getStatesOfCountry(e.target.value);

    setState(state);
  };
  const handleStates = (e) => {
    setSelectedState(e.target.value);
    const city = csc.getCitiesOfState(countryCode, e.target.value);

    setCities(city);
  };

  const handleCities = (e) => {
    setSelectedCity(e.target.value);
  };

  return (
    <div className="home-container">
      <div className="home-contents">
        <div className="home-padding">
          <div className="image-overlay">
            <img src="../images/imgo.png" alt="error" />
          </div>
          <NavHeader state={true} />

          <div className="home-search-box">
            <form>
              <div className="home-search">
                <div className="home-input"></div>
              </div>
            </form>
          </div>
          <div className="service-item">
            <div className="service-box">
              <h2>
                {ids.id}
                <span>
                  <Link
                    to="/"
                    style={{ textDecoration: "none", color: "inherit" }}>
                    Change
                  </Link>
                </span>
              </h2>
              <div className="service-form">
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="service-details">
                    <label>name</label>
                    <input
                      type="text"
                      placeholder="Name"
                      {...register("username", {
                        required: {
                          value: "Required",
                          message: "This field is required",
                        },
                      })}
                    />
                    {errors.username && (
                      <span>
                        <FiAlertTriangle /> This field is required
                      </span>
                    )}
                    <label>Phone No</label>
                    <PhoneInput
                      country="in"
                      inputProps={{
                        name: "phone_number",
                        required: true,
                      }}
                      isValid={value ? true : false}
                      className="search-btn"
                      value={value}
                      onChange={(value) => setValue(value)}
                      searchPlaceholder="Buscar..."
                      containerClass="ease-linear duration-150 p-1 placeholder-gray-400 text-gray-700 bg-white rounded text-sm shadow focus:outline-none focus:shadow-outline w-full"
                      buttonClass="rounded "
                      buttonStyle={{
                        marginRight: "1rem",
                      }}
                      inputStyle={{ paddingLeft: "1rem" }}
                      // enableSearch
                      // searchPlaceholder="Buscar..."
                    />

                    <label>Email ID</label>
                    <input
                      type="email"
                      placeholder="Email Id"
                      {...register("email", {
                        required: "Required",
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: "invalid email address",
                        },
                      })}
                    />
                    {errors.email && (
                      <span>
                        <FiAlertTriangle /> This field is required
                      </span>
                    )}
                  </div>
                  <div className="service-details-2">
                    <div className="select-layout">
                      {/* conditinal render values */}

                      <select
                        name="country"
                        placeholder="country"
                        onChange={handleCountries}
                        className="select">
                        {country.map((countries) => (
                          <option
                            key={countries.isoCode}
                            value={countries.isoCode}>
                            {countries.name}
                          </option>
                        ))}
                      </select>
                      {state && (
                        <select
                          name="state"
                          onChange={handleStates}
                          className="select">
                          {state.map((state) => (
                            <option value={state.isoCode} key={state.isoCode}>
                              {state.name}
                            </option>
                          ))}
                        </select>
                      )}
                      {cities && (
                        <select
                          name="city"
                          onChange={handleCities}
                          className="select">
                          {cities.map((city, index) => (
                            <option value={city.name} key={index}>
                              {city.name}
                            </option>
                          ))}
                        </select>
                      )}
                    </div>
                    <textarea
                      name="Address"
                      cols="30"
                      rows="3"
                      placeholder="address"
                      {...register("address", {
                        required: {
                          value: "Required",
                          message: "This field is required",
                        },
                      })}></textarea>
                    {errors.address && (
                      <span>
                        <FiAlertTriangle />
                        This field is required
                      </span>
                    )}
                    <div className="service-details-3">
                      <p>
                        <strong> On Submit</strong> An OTP will be sent to your
                        Register Mobile Number
                      </p>
                    </div>
                    <button>Submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="home-footer">
            <div className="socail-media-icons">
              <AiOutlineFacebook className="socail-icons" />
              <AiOutlineInstagram className="socail-icons" />
              <AiOutlineTwitter className="socail-icons" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
