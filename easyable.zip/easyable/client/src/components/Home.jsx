/** @format */

import React, { useEffect, useState } from "react";

import {
  AiOutlineFacebook,
  AiOutlineInstagram,
  AiOutlineTwitter,
} from "react-icons/ai";

import Autocomplete from "@material-ui/lab/Autocomplete";
import { TextField } from "@material-ui/core";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useHistory,
} from "react-router-dom";

import Contact from "./Contact";
import NavHeader from "./NavComponents/NavHeader";
import Services from "./Services";

const Home = () => {
  const history = useHistory();

  const [userChoice, setUserChoice] = useState({
    services: "",
  });
  // useEffect(()=>{
  // if(window.location.pathname==="/"){

  // }
  // },[])
  const contents = [
    { services: "Cooking" },
    { services: "Booking" },
    { services: "Accounting" },
    { services: "Travelling" },
  ];
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(userChoice);
    if (userChoice) history.push("/services/" + userChoice.services);
  };

  return (
    <div className="home-container">
      <div className="home-contents">
        <div className="home-padding">
          <div className="image-overlay">
            <img src="../images/imgo.png" alt="error" />
          </div>
          <NavHeader state={true} />

          <div className="home-search-box">
            <div className="home-search-text">
              <h2>
                Find the service <br /> You need in a
                <strong> in a short time</strong>
              </h2>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="home-search">
                <div className="home-input">
                  <Autocomplete
                    className="input"
                    options={contents}
                    getOptionSelected={(option, value) =>
                      option.services === value.services
                    }
                    getOptionLabel={(option) => option.services}
                    onChange={(e, value) => setUserChoice(value)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Search"
                        className="text-field"
                      />
                    )}
                  />
                </div>
                <button className="btn" type="submit"></button>
              </div>
            </form>
          </div>

          <div className="home-body">
            <div className="content-1">
              <img src="../images/c1.png" alt="error" />
            </div>
            <div className="content-2">
              <img src="../images/c2.png" alt="error" />
            </div>
            <div className="content-3">
              <img src="../images/c3.png" alt="error" />
            </div>
            <div className="content-4">
              <img src="../images/c4.png" alt="error" />
            </div>
          </div>

          <div className="home-footer">
            <div className="socail-media-icons">
              <AiOutlineFacebook className="socail-icons" />
              <AiOutlineInstagram className="socail-icons" />
              <AiOutlineTwitter className="socail-icons" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
