/** @format */

import React from "react";
import {
  AiOutlineFacebook,
  AiOutlineInstagram,
  AiOutlineTwitter,
} from "react-icons/ai";
import NavHeader from "./NavComponents/NavHeader";

const About = () => {
  return (
    <div className="home-container" style={{ background: "black" }}>
      <div className="home-contents">
        <div className="home-padding">
          <div className="image-overlay">
            <img src="../images/greenLogo.png" alt="error" />
          </div>
          <NavHeader />
          <div className="about-container">
            <div className="about-contents">
              <div className="about-comp-img">
                <div className="about-grid-1">
                  <img
                    src="https://images.pexels.com/photos/7070/space-desk-workspace-coworking.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
                    alt="error"
                  />
                </div>
                <div className="about-grid-2">
                  <img
                    src="https://images.pexels.com/photos/7065/space-desk-office-hero-7065.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
                    alt="error"
                  />
                </div>
                <div className="about-grid-3">
                  <img
                    src="https://images.pexels.com/photos/7097/people-coffee-tea-meeting.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
                    alt="error"
                  />
                </div>
              </div>
              <div className="about-text">
                <h2>
                  We are Bangalore based startup trying to connect service
                  industry and customer's requirement seamlessly.
                </h2>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Obcaecati facere quis similique repellat exercitationem fuga
                  minus adipisci est voluptatem, consequatur incidunt illo amet
                  quia nulla aliquam, repudiandae, eligendi quod. Nemo.2
                </p>
              </div>
            </div>
          </div>

          <div className="home-footer">
            <div className="socail-media-icons">
              <AiOutlineFacebook className="socail-icons" />
              <AiOutlineInstagram className="socail-icons" />
              <AiOutlineTwitter className="socail-icons" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
