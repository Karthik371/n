/** @format */

import React from "react";
import {
  AiOutlineFacebook,
  AiOutlineInstagram,
  AiOutlineTwitter,
} from "react-icons/ai";
import NavHeader from "./NavComponents/NavHeader";

const Contact = () => {
  return (
    <div className="home-container" style={{ background: "#f7f7f7" }}>
      <div className="home-contents">
        <div className="home-padding">
          <div className="image-overlay">
            <img
              src="../images/greenLogo.png"
              alt="error"
              style={{ opacity: 1, mixBlendMode: "normal" }}
            />
          </div>
          <NavHeader state={false} />
          <div className="contact-container">
            <div className="contact-contents">
              <div className="contact-header">
                <h2>Contact Us</h2>
                <img src="../images/contact.png" alt="error" />
              </div>

              <div className="contact-details">
                <p>88-27-30-0471</p>
                <p>
                  KP Eden 16, Bhuvanappa Layout, Tavarekere Main Rd, Bengaluru,
                  560029
                </p>
                <p>
                  <strong>contact@easyable.com </strong>
                </p>
              </div>
            </div>
          </div>
          <div className="home-footer">
            <div className="socail-media-icons">
              <AiOutlineFacebook
                className="socail-icons"
                style={{ color: "lightgreen" }}
              />
              <AiOutlineInstagram
                className="socail-icons"
                style={{ color: "lightgreen" }}
              />
              <AiOutlineTwitter
                className="socail-icons"
                style={{ color: "lightgreen" }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
