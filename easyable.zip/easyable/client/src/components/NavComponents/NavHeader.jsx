/** @format */

import React, { useState } from "react";

import { GrUserSettings } from "react-icons/gr";
import { Link } from "react-router-dom";
import { AiOutlineUser } from "react-icons/ai";
import { BiLogIn } from "react-icons/bi";

const NavHeader = ({ state }) => {
  const [navState, setNavState] = useState(false);
  return (
    <div className="nav-header">
      <div className="nav-bar">
        <div
          className={navState ? "menu menu-active" : "menu"}
          onClick={() => setNavState(!navState)}>
          <span
            style={
              !state ? { background: "lightgreen" } : { background: "white" }
            }></span>
          <span
            style={
              !state ? { background: "lightgreen" } : { background: "white" }
            }></span>
          <span
            style={
              !state ? { background: "lightgreen" } : { background: "white" }
            }></span>
        </div>
        <div
          className={
            navState
              ? "nav-bar-details nav-bar-details-active "
              : "nav-bar-details"
          }>
          <ul className="nav-bar-ul">
            <li>
              <Link to="/" style={{ textDecoration: "none", color: "white" }}>
                Home
              </Link>
            </li>
            <li>
              <Link
                to="/about"
                style={{ textDecoration: "none", color: "white" }}
                className="nav-links">
                About
              </Link>
            </li>
            <li>
              <Link
                to="/contact"
                style={{ textDecoration: "none", color: "white" }}>
                Contact
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="brand-logo">
        <img
          src={state ? "../images/logo.png" : "../images/greenlogomain.png"}
          alt="error"
        />
      </div>
      <div className="profile-user">
        <div className="profile-name">
          <p>Hi Guest</p>
        </div>
        <div className="profile-img">
          <img
            src="https://images.pexels.com/photos/428361/pexels-photo-428361.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
            alt="err"
          />
        </div>
        <div className="drop-down">
          <ul>
            <li>
              <GrUserSettings className="drop-icons" />
              FAQ
            </li>
            <li>
              <AiOutlineUser className="drop-icons" /> Profile
            </li>
            <li>
              <BiLogIn className="drop-icons" /> Login
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default NavHeader;
