/** @format */

const express = require("express");
const cors = require("cors");
const connection = require("../server/config/mongoose");
connection();
const app = express();
app.use(express.static("public"));
app.use(express.json());
app.use(cors());

app.use("/", require("../server/routes/userRoute"));

app.listen(4000, function () {
  console.log("server is running");
});
